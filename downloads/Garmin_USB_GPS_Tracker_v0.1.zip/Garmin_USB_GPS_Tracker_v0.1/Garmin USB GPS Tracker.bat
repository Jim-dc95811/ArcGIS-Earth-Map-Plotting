@echo off
title Garmin USB GPS Tracker
cd /d "%~dp0"
where py >nul 2>nul && ( py "System Files\garmin_tracker_app.py" & goto done )
where python >nul 2>nul && ( python "System Files\garmin_tracker_app.py" & goto done )
echo.
echo   Python 3 was not found. Install it from https://www.python.org/downloads/
echo   and tick "Add python.exe to PATH", then run this again.
echo.
pause
:done
