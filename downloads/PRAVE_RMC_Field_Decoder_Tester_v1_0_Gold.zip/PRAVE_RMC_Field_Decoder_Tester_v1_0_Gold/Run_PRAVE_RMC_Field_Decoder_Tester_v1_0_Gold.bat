@echo off
setlocal
cd /d "%~dp0"
title PRAVE RMC Field Decoder Tester - Version 1.0 Gold

rem --- Find Python 3 (py launcher first, then python) ---
set "PYEXE=py -3"
where py >nul 2>nul || set "PYEXE=python"
%PYEXE% --version >nul 2>nul
if errorlevel 1 (
    echo Python 3 was not found. Install it from https://www.python.org/downloads/windows/
    echo using the default options, then run this again.
    pause
    exit /b 1
)
rem --- pyserial: install it once if it is missing ---
%PYEXE% -c "import serial" >nul 2>nul
if errorlevel 1 (
    echo pyserial is not installed yet. Installing it now - one time only...
    echo.
    %PYEXE% -m pip install pyserial
    %PYEXE% -c "import serial" >nul 2>nul
    if errorlevel 1 (
        echo.
        echo pyserial could not be installed automatically.
        echo Open Command Prompt and run:  py -3 -m pip install pyserial
        echo If your network blocks downloads, ask IT to install pyserial for Python 3.
        pause
        exit /b 1
    )
    echo.
    echo pyserial installed.
    echo.
)
echo ============================================================
echo   PRAVE / RMC Field Decoder Tester - Version 1.0 Gold
echo ============================================================
echo.
echo COM port and baud rate are configured at the top of the
echo Python file. Press Ctrl+C to stop the live test stream.
echo.

%PYEXE% "System Files\PRAVE_RMC_Field_Decoder_Tester_v1_0_Gold.py"

echo.
echo ============================================================
echo Tester exited.
echo ============================================================
pause
endlocal
