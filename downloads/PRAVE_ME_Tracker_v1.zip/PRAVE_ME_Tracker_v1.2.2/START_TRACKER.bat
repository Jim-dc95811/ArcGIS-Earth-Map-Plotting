@echo off
setlocal
cd /d "%~dp0"
title ArcGIS Earth PRAVE / ME Tracker

rem --- Find Python 3 (py launcher first, then python) ---
set "PYEXE=py -3"
where py >nul 2>nul || set "PYEXE=python"
%PYEXE% --version >nul 2>nul
if errorlevel 1 (
    echo Python 3 was not found. Install it from https://www.python.org/downloads/windows/
    echo using the default options, then run this again.
    pause
    exit /b 1
)
rem --- pyserial: install it once if it is missing ---
%PYEXE% -c "import serial" >nul 2>nul
if errorlevel 1 (
    echo pyserial is not installed yet. Installing it now - one time only...
    echo.
    %PYEXE% -m pip install pyserial
    %PYEXE% -c "import serial" >nul 2>nul
    if errorlevel 1 (
        echo.
        echo pyserial could not be installed automatically.
        echo Open Command Prompt and run:  py -3 -m pip install pyserial
        echo If your network blocks downloads, ask IT to install pyserial for Python 3.
        pause
        exit /b 1
    )
    echo.
    echo pyserial installed.
    echo.
)
%PYEXE% "System Files\PRAVE_ME_Tracker.py"

set EXITCODE=%errorlevel%
echo.
echo PRAVE / ME Tracker exited with code %EXITCODE%.
pause
exit /b %EXITCODE%
