@echo off
title P25 Aliases - PRAVE / ME Tracker
cd /d "%~dp0"

rem Prefer the Python that START_TRACKER.bat already found and saved.
set "PYEXE="
if exist "%~dp0System Files\python_path.txt" set /p PYEXE=<"%~dp0System Files\python_path.txt"
if defined PYEXE (
    "%PYEXE%" "System Files\p25_alias_editor.py"
    goto done
)

where py >nul 2>nul
if %errorlevel%==0 (
    py "System Files\p25_alias_editor.py"
    goto done
)
where python >nul 2>nul
if %errorlevel%==0 (
    python "System Files\p25_alias_editor.py"
    goto done
)

echo.
echo   Python was not found on this PC yet.
echo   Run START_TRACKER.bat once first (it sets up Python), then open this again.
echo.
pause

:done
