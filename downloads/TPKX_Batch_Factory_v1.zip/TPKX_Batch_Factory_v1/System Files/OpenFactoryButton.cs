using ArcGIS.Desktop.Framework.Contracts;

namespace ArcGIS_TPKX_Factory
{
    internal class OpenFactoryButton : Button
    {
        protected override void OnClick()
        {
            BatchWindow.ShowFactory();
        }
    }
}
