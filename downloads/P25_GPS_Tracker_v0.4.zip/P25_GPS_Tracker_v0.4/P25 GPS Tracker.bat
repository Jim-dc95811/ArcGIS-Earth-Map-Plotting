@echo off
title P25 GPS Tracker
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py "System Files\p25_tracker_app.py" %*
    goto done
)
where python >nul 2>nul
if %errorlevel%==0 (
    python "System Files\p25_tracker_app.py" %*
    goto done
)

echo.
echo   Python was not found on this PC.
echo   Install Python 3 from https://www.python.org/downloads/
echo   and tick "Add Python to PATH" during setup, then run this again.
echo.
pause

:done
